/*
 * Copyright (C) 2022 David C. Harrison
 *
 * DO NOT MODIFY OR REMOVE THIS FILE
 */
package edu.ucsc.cse118.assignment3.ui.fake

import androidx.fragment.app.Fragment

class FakeFragment : Fragment()