import SwiftUI

@main
struct Assignment5App: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack{
                WorkspaceList()
            }
        }
    }
}
